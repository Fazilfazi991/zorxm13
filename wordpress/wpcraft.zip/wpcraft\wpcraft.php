<?php
/**
 * Plugin Name: WPCraft — AI Page Builder
 * Description: AI-powered page builder. 
 *   Generate and edit pages with AI.
 * Version: 2.0.0
 * Author: Zorx Digital
 * Author URI: https://zorx.co
 */

if (!defined('ABSPATH')) exit;

define('WPCRAFT_VERSION', '2.0.0');
define('WPCRAFT_DIR', plugin_dir_path(__FILE__));
define('WPCRAFT_URL', plugin_dir_url(__FILE__));

class WPCraft_V2 {

  private static $instance = null;

  public static function instance() {
    if (!self::$instance) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  public function __construct() {
    add_action('init', [$this, 'init']);
  }

  public function init() {
    // Load REST API
    require_once WPCRAFT_DIR . 'includes/api.php';
    require_once WPCRAFT_DIR . 'includes/renderer.php';
    
    // Add "Edit with WPCraft" button 
    // to admin bar
    add_action('admin_bar_menu', 
      [$this, 'admin_bar_button'], 100);
    
    // Add edit button on post list
    add_filter('page_row_actions', 
      [$this, 'page_row_action'], 10, 2);
    add_filter('post_row_actions',
      [$this, 'page_row_action'], 10, 2);
    
    // Handle editor page load
    add_action('admin_menu', 
      [$this, 'register_editor_page']);
    
    // Render page on frontend
    add_filter('the_content',
      [$this, 'render_wpcraft_page']);
    
    // Enqueue frontend styles
    add_action('wp_enqueue_scripts',
      [$this, 'enqueue_frontend']);
  }

  public function admin_bar_button($wp_admin_bar) {
    if (!is_singular()) return;
    if (!current_user_can('edit_posts')) return;
    
    $post_id = get_the_ID();
    $url = admin_url(
      'admin.php?page=wpcraft-editor&post_id=' . 
      $post_id
    );
    
    $wp_admin_bar->add_node([
      'id' => 'wpcraft-edit',
      'title' => '✦ Edit with WPCraft',
      'href' => $url,
      'meta' => ['target' => '_blank']
    ]);
  }

  public function page_row_action($actions, $post) {
    if (!current_user_can('edit_post', $post->ID)) {
      return $actions;
    }
    $url = admin_url(
      'admin.php?page=wpcraft-editor&post_id=' . 
      $post->ID
    );
    $actions['wpcraft'] = 
      '<a href="' . $url . '" target="_blank">' .
      '✦ WPCraft</a>';
    return $actions;
  }

  public function register_editor_page() {
    add_menu_page(
      'WPCraft Editor',
      'WPCraft',
      'edit_posts',
      'wpcraft-editor',
      [$this, 'render_editor'],
      'dashicons-art',
      30
    );
    add_submenu_page(
      'wpcraft-editor',
      'Settings',
      'Settings', 
      'manage_options',
      'wpcraft-settings',
      [$this, 'render_settings']
    );
  }

  public function render_settings() {
    if (isset($_POST['wpcraft_gemini_key'])) {
      check_admin_referer('wpcraft_settings');
      update_option(
        'wpcraft_gemini_key',
        sanitize_text_field(
          $_POST['wpcraft_gemini_key']
        )
      );
      echo '<div class="notice notice-success">
        <p>Settings saved.</p></div>';
    }
    $key = get_option('wpcraft_gemini_key', '');
    ?>
    <div class="wrap">
      <h1>WPCraft Settings</h1>
      <form method="post">
        <?php wp_nonce_field('wpcraft_settings'); ?>
        <table class="form-table">
          <tr>
            <th>Gemini API Key</th>
            <td>
              <input type="password" 
                name="wpcraft_gemini_key"
                value="<?php echo esc_attr($key); ?>"
                class="regular-text" />
              <p class="description">
                Get your key from 
                <a href="https://aistudio.google.com" 
                  target="_blank">
                  Google AI Studio
                </a>
              </p>
            </td>
          </tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
    <?php
  }

  public function render_editor() {
    $post_id = intval($_GET['post_id'] ?? 0);
    
    if (!$post_id) {
      // Show page selector if no post_id
      $this->render_page_selector();
      return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
      wp_die('Permission denied');
    }
    
    $post = get_post($post_id);
    if (!$post) wp_die('Page not found');
    
    $nonce = wp_create_nonce('wpcraft_nonce');
    $api_base = rest_url('wpcraft/v2/');
    $existing_data = get_post_meta(
      $post_id, '_wpcraft_data', true
    ) ?: '{}';
    
    // Full screen editor - hide WP chrome
    ?>
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" 
        content="width=device-width, 
        initial-scale=1.0">
      <title>WPCraft — 
        <?php echo esc_html($post->post_title); ?>
      </title>
      <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        html, body { 
          width:100%; height:100%; 
          overflow:hidden; 
          background:#0f0f0f;
        }
        #wpcraft-editor { 
          width:100%; height:100vh; 
        }
      </style>
    </head>
    <body>
      <div id="wpcraft-editor"></div>
      <script>
        window.WPCRAFT_CONFIG = {
          postId: <?php echo $post_id; ?>,
          postTitle: <?php echo json_encode(
            $post->post_title
          ); ?>,
          nonce: "<?php echo $nonce; ?>",
          apiBase: "<?php echo $api_base; ?>",
          pageData: <?php echo $existing_data; ?>,
          siteUrl: "<?php echo get_site_url(); ?>",
          adminUrl: "<?php echo admin_url(); ?>"
        };
      </script>
      <?php
      // Load the React editor bundle
      $js = WPCRAFT_URL . 'editor/assets/index.js';
      $css = WPCRAFT_URL . 'editor/assets/index.css';
      ?>
      <link rel="stylesheet" href="<?php echo $css; ?>">
      <script type="module" src="<?php echo $js; ?>">
      </script>
    </body>
    </html>
    <?php
    exit;
  }

  private function render_page_selector() {
    $pages = get_posts([
      'post_type' => ['page', 'post'],
      'posts_per_page' => 20,
      'post_status' => 'any',
      'orderby' => 'modified',
      'order' => 'DESC'
    ]);
    ?>
    <div class="wrap">
      <h1>✦ WPCraft Editor</h1>
      <p>Select a page to edit:</p>
      <table class="wp-list-table widefat">
        <thead>
          <tr>
            <th>Title</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pages as $page): ?>
          <tr>
            <td><?php echo esc_html(
              $page->post_title
            ); ?></td>
            <td><?php echo esc_html(
              $page->post_status
            ); ?></td>
            <td>
              <a href="<?php echo admin_url(
                'admin.php?page=wpcraft-editor&post_id=' 
                . $page->ID
              ); ?>" target="_blank">
                Edit with WPCraft →
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <br>
      <a href="<?php echo admin_url(
        'post-new.php?post_type=page'
      ); ?>" class="button button-primary">
        Create New Page
      </a>
    </div>
    <?php
  }

  public function render_wpcraft_page($content) {
    if (!is_singular()) return $content;
    
    $post_id = get_the_ID();
    $wpcraft_data = get_post_meta(
      $post_id, '_wpcraft_data', true
    );
    
    if (!$wpcraft_data) return $content;
    
    $data = json_decode($wpcraft_data, true);
    if (!$data || empty($data['sections'])) {
      return $content;
    }
    
    return wpcraft_render_page($data);
  }

  public function enqueue_frontend() {
    if (!is_singular()) return;
    $post_id = get_the_ID();
    $has_wpcraft = get_post_meta(
      $post_id, '_wpcraft_data', true
    );
    if (!$has_wpcraft) return;
    
    // Enqueue Google Fonts
    wp_enqueue_style(
      'wpcraft-fonts',
      'https://fonts.googleapis.com/css2?' .
      'family=Inter:wght@400;500;600;700&' .
      'family=DM+Sans:wght@400;500;600;700;800&' .
      'display=swap',
      [], null
    );
    
    // Inline reset styles
    wp_add_inline_style('wpcraft-fonts', '
      .wpcraft-page * { box-sizing: border-box; }
      .wpcraft-page img { max-width: 100%; }
      .wpcraft-page a { text-decoration: none; }
    ');
  }
}

WPCraft_V2::instance();
